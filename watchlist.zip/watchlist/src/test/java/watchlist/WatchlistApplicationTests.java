package watchlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
